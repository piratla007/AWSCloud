import json
import base64

def lambda_handler(event, context):
    event1 = {
        'records': 
            [
                {
                    'recordId': u'49588196600558685282207290933487022116280636383103549442000000',
                    'data': u'eyJ0aWNrZXJfc3ltYm9sIjoiREVHIiwic2VjdG9yIjoiRU5FUkdZIiwiY2hhbmdlIjowLjA2LCJwcmljZSI6My42OH0=', 
                    'approximateArrivalTimestamp': 1536777093916
                }, 
                {
                    'recordId': u'49588196600558685282207290933488231042100251012278255618000000',
                    'data': u'eyJ0aWNrZXJfc3ltYm9sIjoiTkZMWCIsInNlY3RvciI6IlRFQ0hOT0xPR1kiLCJjaGFuZ2UiOjAuMjksInByaWNlIjoxMTAuMzl9', 
                    'approximateArrivalTimestamp': 1536777093919
                }
            ]
    }
    output=[]
    for each_record in event["records"]:
        # out_event=each_record["data"].decode('base64')
        out_event = json.loads(each_record["data"].decode('base64'))
        if out_event["sector"] == "ENERGY":
            output_record = {
                'recordId': each_record['recordId'],
                'result': 'Ok',
                'data': each_record["data"]
                }
        else:
            output_record = {
                'recordId': each_record['recordId'],
                'result': 'Dropped',
                'data': each_record["data"]
            }
            print "Ignoring record: ", out_event
        output.append(output_record)
    # print('Successfully processed {} records.'.format(len(event['records'])))
    return {'records': output}
    